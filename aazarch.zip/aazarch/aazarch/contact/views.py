from django.contrib import messages
from django.shortcuts import render, redirect

# Create your views here.
from .forms import ContactForm
from .models import Contact



def contact2(request):
    context = {}

    # create object of form
    form = ContactForm(request.POST or None)

    if form.is_valid():
        new_message = form.save(commit=False)
        new_message.replied = False
        new_message.save()
        return redirect('motors:home')

    context['form'] = form
    return render(request, "pages/contact.html", context)


def contact(request):
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'pages/contact.html', {'form': ContactForm(request.GET)})
    else:
        form = ContactForm()
    return render(request, 'pages/contact.html', {'form': form})
