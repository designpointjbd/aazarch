from django.db import models

# Create your models here.

class Headoffice(models.Model):
    title = models.CharField(max_length=100)
    icon = models.ImageField(upload_to='contact/icons')
    address = models.CharField(max_length=200)

class Phone(models.Model):
    title = models.CharField(max_length=100)
    icon = models.ImageField(upload_to='contact/icons')
    address = models.CharField(max_length=200)

class Email(models.Model):
    title = models.CharField(max_length=100)
    icon = models.ImageField(upload_to='contact/icons')
    address = models.CharField(max_length=200)

class Showroom(models.Model):
    title = models.CharField(max_length=100)
    icon = models.ImageField(upload_to='contact/icons')
    address = models.CharField(max_length=200)

class Contact(models.Model):
    name = models.CharField(max_length=50)
    phone = models.CharField(max_length=13)
    message = models.CharField(max_length=200)
    replied = models.BooleanField(default=False)
    date = models.DateField(auto_now_add=True)

