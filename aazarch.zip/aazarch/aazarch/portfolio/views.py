from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from .choices import *
from django.contrib import messages
from django.core.paginator import Paginator
from .forms import SellVehicle
# Create your views here.
from .models import Portfolio, News, Review, Team, Service, Brand, About
from contact.models import *
from contact.forms import ContactForm
from sections.models import *


def home(request):
    portfolio = Portfolio.objects.all()[:12]

    teamlist = Team.objects.all()[:4]
    galleryimages = Portfolio.objects.all()
    fullwidth3ads = Portfolio.objects.all()[:3]
    # featuredcars = Portfolio.objects.filter(featured=True)
    services = Service.objects.all()[:6]


    services_sec = ServicesSection.objects.all()[:1]
    project_sec = ProjectsSection.objects.all()[:1]
    team_sec = TeamSection.objects.all()[:1]
    contact_sec = ContactSection.objects.all()[:1]




    about = About.objects.all()[:1]

    recent_cars = Portfolio.objects.all()
    paginator = Paginator(recent_cars, 8)
    page = request.GET.get('page')
    paged_cars = paginator.get_page(page)

    context = {
        'form': ContactForm(request.GET),
        'services_sec': services_sec,
        'project_sec': project_sec,
        'team_sec': team_sec,
        'contact_sec': contact_sec,

        'model_choices': model_choices,
        'condition_choices': condition_choices,
        'type_choices': type_choices,

        'services': services,
        'fullwidth3ads': fullwidth3ads,
        'portfolio': portfolio,
        'teamlist': teamlist,

        'recent_cars': paged_cars,

        'about': about,

        'galleryimages': galleryimages,
    }

    form = ContactForm(request.POST or None)

    if form.is_valid():
        new_message = form.save(commit=False)
        new_message.replied = False
        new_message.save()
        return redirect('/')

    return render(request, "index.html", context)


def cars(request):
    cars = Portfolio.objects.all()
    allbrands = Brand.objects.all()



    paginator = Paginator(cars, 8)
    page = request.GET.get('page')
    paged_cars = paginator.get_page(page)

    context = {
        'paged_cars': paged_cars,
        'allbrands': allbrands,
    }
    return render(request, "motors/inventory-list.html", context)


def cardetail(request, car_id):
    cardetails = get_object_or_404(Portfolio, pk=car_id)
    context = {
        'cardetails': cardetails,
    }
    return render(request, 'motors/vehicle-details.html', context)

def myads(request):
    mycars = Portfolio.objects.filter(owner=request.user)
    context = {
        'mycars': mycars,
    }
    return render(request, 'motors/myads.html', context)


def remove_ad(request, pk):
    mycars = Portfolio.objects.filter(owner=request.user)

    delcar = get_object_or_404(Portfolio, pk=pk)
    delcar.delete()

    context = {
        'mycars': mycars,
    }
    return render(request, 'motors/myads.html', context)

def compare(request):
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        counter = car_ids.split('|')
        car_count_in_compare = len(set(counter))
    else:
        car_count_in_compare = 0

    # fetching car details from db whose id is present in cookie
    cars = None
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        if car_ids != "":
            car_id_in_compare = car_ids.split('|')
            cars = Portfolio.objects.all().filter(id__in=car_id_in_compare)[:3]

    return render(request, 'motors/compare.html',
                  {'cars': cars, 'car_count_in_compare': car_count_in_compare})


def add_to_compare(request, pk):
    cars = Portfolio.objects.all()
    recent_cars = Portfolio.objects.all()
    teamlist = Team.objects.all()[:4]
    featuredcars = Portfolio.objects.filter(featured=True)
    allnews = News.objects.all()[:3]
    allreviews = Review.objects.filter(active=True)[:10]

    # for compare counter, fetching car ids added by customer from cookies
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        counter = car_ids.split('|')
        car_count_in_compare = len(set(counter))
    else:
        car_count_in_compare = 1

    context = {'recent_cars': recent_cars,
               'cars': cars,
               'car_count_in_compare': car_count_in_compare,
               'teamlist': teamlist,
               'featuredcars': featuredcars,
               'allnews': allnews,
               'allreviews': allreviews,
               }

    response = render(request, 'home.html', context)

    # adding car id to cookies
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        if car_ids == "":
            car_ids = str(pk)
        else:
            car_ids = car_ids + "|" + str(pk)
        response.set_cookie('car_ids', car_ids)
    else:
        response.set_cookie('car_ids', pk)

    car = Portfolio.objects.get(id=pk)
    messages.info(request, car.name + ' added to compare successfully!')

    return response


def remove_from_compare(request, pk):
    # for counter in compare
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        counter = car_ids.split('|')
        car_count_in_compare = len(set(counter))
    else:
        car_count_in_compare = 0

    # removing car id from cookie
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        car_id_in_compare = car_ids.split('|')
        car_id_in_compare = list(set(car_id_in_compare))
        car_id_in_compare.remove(str(pk))
        cars = Portfolio.objects.all().filter(id__in=car_id_in_compare)

        #  for update coookie value after removing car id in compare
        value = ""
        for i in range(len(car_id_in_compare)):
            if i == 0:
                value = value + car_id_in_compare[0]
            else:
                value = value + "|" + car_id_in_compare[i]
        response = render(request, 'motors/compare.html',
                          {'cars': cars, 'car_count_in_compare': car_count_in_compare})
        if value == "":
            response.delete_cookie('car_ids')
        response.set_cookie('car_ids', value)
        return response


def news(request):
    allnews = News.objects.all()
    paginator = Paginator(allnews, 8)
    page = request.GET.get('page')
    paged_news = paginator.get_page(page)
    context = {
        'allnews': paged_news,
    }
    return render(request, "blog/blog-main.html", context)


def newsdetail(request, news_id):
    newsdetail = get_object_or_404(News, pk=news_id)
    context = {
        'newsdetail': newsdetail,
    }
    return render(request, 'blog/blog-post.html', context)

def dealers(request):
    return render(request, "dealers/dealers.html")


def dealerdetail(request):
    return render(request, 'dealers/dealer-info.html')

@login_required(login_url="/account/signin/")
def submit(request):
    form = SellVehicle(request.POST or None, request.FILES or None)
    if form.is_valid():
        obj = form.save(commit=False)
        obj.user = request.user
        obj.save()
    return render(request, "motors/submit.html", {"form": form})



def search(request):
    queryset_list = Portfolio.objects.order_by('-price')
    # Filter by Vehicle type
    if 'category' in request.GET:
        types = request.GET['category']
        if types:
            queryset_list = queryset_list.filter(category__icontains=types)
    # Filter by Make
    if 'make_choice' in request.GET:
        make = request.GET['make_choice']
        if make:
            queryset_list = queryset_list.filter(name__iexact=make)
    # Filter Models
    if 'model' in request.GET:
        models = request.GET['model']
        if models:
            queryset_list = queryset_list.filter(model__iexact=models)

    # New or used
    if 'condition' in request.GET:
        new_or_used = request.GET['condition']
        if new_or_used:
            queryset_list = queryset_list.filter(condition__iexact=new_or_used)
    # Price
    # if 'price' in request.GET:
    #    price = request.GET['price']
    #    if price:
    #        queryset_list = queryset_list.filter(price__lte=price)

    context = {
        'queryset_list': queryset_list,

        'make_choices': make_choices,
        'status_choices': status_choices,
        'type_choices': type_choices,

        'condition_choices': condition_choices,
        'model_choices': model_choices,
        'values': request.GET
    }
    return render(request, 'search.html', context)


def bookmarks(request):
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        counter = car_ids.split('|')
        car_count_in_bookmark = len(set(counter))
    else:
        car_count_in_bookmark = 0

    # fetching car details from db whose id is present in cookie
    cars = None
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        if car_ids != "":
            car_count_in_bookmark = car_ids.split('|')
            cars = Portfolio.objects.all().filter(id__in=car_count_in_bookmark)

    return render(request, 'motors/bookmarks.html',
                  {'cars': cars, 'car_count_in_bookmark': car_count_in_bookmark})


def add_bookmark(request, pk):
    cars = Portfolio.objects.all()
    teamlist = Team.objects.all()[:4]
    featuredcars = Portfolio.objects.filter(featured=True)
    allnews = News.objects.all()[:3]
    allreviews = Review.objects.filter(active=True)[:10]

    # for compare counter, fetching car ids added by customer from cookies
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        counter = car_ids.split('|')
        car_count_in_bookmark = len(set(counter))
    else:
        car_count_in_bookmark = 1

    context = {'cars': cars,
               'car_count_in_bookmark': car_count_in_bookmark,
               'teamlist': teamlist,
               'featuredcars': featuredcars,
               'allnews': allnews,
               'allreviews': allreviews,
               }

    response = render(request, 'home.html', context)

    # adding car id to cookies
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        if car_ids == "":
            car_ids = str(pk)
        else:
            car_ids = car_ids + "|" + str(pk)
        response.set_cookie('car_ids', car_ids)
    else:
        response.set_cookie('car_ids', pk)

    car = Portfolio.objects.get(id=pk)
    messages.info(request, car.name + ' Bookmarked successfully!')

    return response


def remove_bookmark(request, pk):
    # for counter in compare
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        counter = car_ids.split('|')
        car_count_in_bookmark = len(set(counter))
    else:
        car_count_in_bookmark = 0

    # removing car id from cookie
    if 'car_ids' in request.COOKIES:
        car_ids = request.COOKIES['car_ids']
        car_id_in_bookmark = car_ids.split('|')
        car_id_in_bookmark = list(set(car_id_in_bookmark))
        car_id_in_bookmark.remove(str(pk))
        cars = Portfolio.objects.all().filter(id__in=car_id_in_bookmark)

        #  for update coookie value after removing car id in compare
        value = ""
        for i in range(len(car_id_in_bookmark)):
            if i == 0:
                value = value + car_id_in_bookmark[0]
            else:
                value = value + "|" + car_id_in_bookmark[i]
        response = render(request, 'motors/bookmarks.html',
                          {'cars': cars, 'car_count_in_bookmark': car_count_in_bookmark})
        if value == "":
            response.delete_cookie('car_ids')
        response.set_cookie('car_ids', value)
        return response

