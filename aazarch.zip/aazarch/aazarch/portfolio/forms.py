from django import forms
from .models import Portfolio


class SellVehicle(forms.ModelForm):
    class Meta:
        model = Portfolio
        fields = "__all__"

        exclude = ['owner', 'featured', 'date']


        # TextInput EmailInput  NumberInput Select FileInput DateInput
        widgets = {
            'category': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: John Doe'}),
            'name': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Ex: john@gmail.com'}),
            'status': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 30'}),
            'model': forms.Select(attrs={'class': 'form-control'}),
            'image': forms.FileInput(attrs={'class': 'form-control'}),
            'mileage': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Mileage in KM'}),
            'vin': forms.DateInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 1VXEDYROTER'}),
            'version': forms.TextInput(attrs={'class': 'form-control'}),
            'fuel': forms.Select(attrs={'class': 'form-control'}),
            'engine': forms.Select(attrs={'class': 'form-control', 'placeholder': 'Engine Power'}),
            'power': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Ex: 800HP'}),

            'transmission': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Automatic/Manual'}),
            'doors': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Number of Doors'}),
            'condition': forms.Select(attrs={'class': 'form-control'}),
            'drive': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Right or Left?'}),
            'seats': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Number of Seats'}),
            'external_color': forms.DateInput(attrs={'class': 'form-control', 'placeholder': 'Ex: Brown'}),
            'interior_color': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ex: Grey'}),
            'price': forms.NumberInput(attrs={'class': 'form-control'}),
            'price_type': forms.Select(attrs={'class': 'form-control'}),
            'warranty': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'In Years'}),
        }
