from django.urls import path
from . import views

app_name = "portfolio"

urlpatterns = [
    path('', views.home, name='home'),
    #path('cars', views.cars, name='cars'),
    #path('car/<int:car_id>/', views.cardetail, name='cardetail'),

    #path('compare/', views.compare, name='compare'),
    #path('add-to-compare/<int:pk>', views.add_to_compare, name='add-to-compare'),
    #path('remove-from-compare/<int:pk>', views.remove_from_compare, name='remove-from-compare'),

    #path('myads/', views.myads, name='myads'),
    #path('remove_ad/<int:pk>', views.remove_ad, name='remove_ad'),

    #path('bookmarks/', views.bookmarks, name='bookmarks'),
    #path('add_bookmark/<int:pk>', views.add_bookmark, name='add_bookmark'),
    #path('remove_bookmark/<int:pk>', views.remove_bookmark, name='remove_bookmark'),


    #path('submit/', views.submit, name='submit'),

    #path('dealers/', views.dealers, name='dealers'),
    #path('dealer/<int:dealers_id>/', views.dealerdetail, name='dealerdetail'),

    #path('search', views.search, name='search'),
]
