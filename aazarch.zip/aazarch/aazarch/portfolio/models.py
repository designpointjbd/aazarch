from django.db import models
from .choices import *
from django.contrib.auth.models import User
from ckeditor.fields import RichTextField
# Create your models here.


class Brand(models.Model):
    title = models.CharField(max_length=100)
    logo = models.ImageField(upload_to='brands')

    def __str__(self):
        return self.title


# Sell or Rent?
STATUS_CHOICES = [(k, v) for k, v in status_choices.items()]

# Petrol or Diesel?
FUEL_CHOICES= [(k, v) for k, v in fuel_choices.items()]

# New or used car?
CONDITION_CHOICES = [(k, v) for k, v in condition_choices.items()]

# Toyota, Audi, Mercedes, suzuki etc
MAKE_CHOICES = [(k, v) for k, v in make_choices.items()]

# 2017, 2018, 2019, 2020 or 2021 etc.
MODEL_CHOICES = [(k, v) for k, v in model_choices.items()]

# Car, Pickup, Mazda, or any other?
TYPE_CHOICES= [(k, v) for k, v in type_choices.items()]




class News(models.Model):
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=50)
    image = models.ImageField(upload_to='News/%Y/%m/%d/', null=True, blank=True)
    description = models.TextField()
    date = models.DateField(auto_now=True)

    def __str__(self):
        return self.title + "   --|||--   " + self.author


class Review(models.Model):
    name = models.CharField(max_length=50)
    designation = models.CharField(default='Customer', max_length=50, null=True, blank=True)
    image = models.ImageField(upload_to='Reviews/%Y/%m/%d/', null=True, blank=True)
    message = models.TextField(max_length=300)
    date = models.DateField(auto_now=True)
    active = models.BooleanField(default=False)

    def __str__(self):
        return self.name + "   --|||--   " + self.designation


class Team(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='team')
    mobile = models.CharField(max_length=13)
    designation = models.CharField(max_length=100)
    twitter = models.CharField(max_length=100, null=True, blank=True)
    behance = models.CharField(max_length=100, null=True, blank=True)
    facebook = models.CharField(max_length=100, null=True, blank=True)
    instagram = models.CharField(max_length=100, null=True, blank=True)
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class Service(models.Model):
    title = models.CharField(max_length=100)
    slug = models.SlugField(auto_created=True)
    logo = models.ImageField(upload_to='services/icons', null=True, blank=True)
    image = models.ImageField(upload_to='services', null=True, blank=True)
    description = models.CharField(max_length=500, null=True, blank=True)
    category = models.CharField(choices=TYPE_CHOICES, max_length=50)

    keypoint1 = models.CharField(max_length=30, null=True, blank=True)
    keypoint2 = models.CharField(max_length=30, null=True, blank=True)
    keypoint3 = models.CharField(max_length=30, null=True, blank=True)
    keypoint4 = models.CharField(max_length=30, null=True, blank=True)

    active = models.BooleanField(default=True)

    def __str__(self):
        return self.title

class Portfolio(models.Model):
    title = models.CharField(max_length=100)
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    desc = models.CharField(max_length=500)
    small_image = models.ImageField(upload_to='services', null=True, blank=True)
    large_image = models.ImageField(upload_to='services', null=True, blank=True)

    def __str__(self):
        return self.title

class About(models.Model):
    company_name = models.CharField(max_length=200)
    company_nick = models.CharField(max_length=200)
    tag_line = models.CharField(max_length=150)

    image = models.ImageField(default='about', null=True, blank=True)

    favicon = models.ImageField(default='fav.ico', null=True, blank=True)

    address = models.CharField(max_length=200)
    phone = models.CharField(max_length=13)
    email = models.EmailField()

    description = RichTextField()

    facebook = models.CharField(max_length=100, null=True, blank=True)
    twitter = models.CharField(max_length=100, null=True, blank=True)
    youtube = models.CharField(max_length=100, null=True, blank=True)
    linkedin = models.CharField(max_length=100, null=True, blank=True)
    pinterest = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.company_name