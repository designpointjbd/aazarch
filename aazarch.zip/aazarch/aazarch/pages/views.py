from django.shortcuts import render
from portfolio.models import Portfolio, Review, Team, Brand
# Create your views here.



def about(request):
    galleryimages = Portfolio.objects.all()
    allreviews = Review.objects.filter(active=True)[:10]
    teamlist = Team.objects.all()[:4]
    allbrands = Brand.objects.all()
    context = {
        'galleryimages': galleryimages,
        'allreviews': allreviews,
        'teamlist': teamlist,
        'allbrands': allbrands,
    }
    return render(request, "pages/about.html", context)

def contact(request):
    return render(request, 'pages/contact.html')

def privacy(request):
    return render(request, 'pages/contact.html')

def terms(request):
    return render(request, 'pages/contact.html')

def faqs(request):
    return render(request, 'pages/contact.html')
