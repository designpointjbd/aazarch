from django.db import models

# Create your models here.

class ServicesSection(models.Model):
    title = models.CharField(max_length=100)
    desc = models.CharField(max_length=500)

    def __str__(self):
        return self.title

class ProjectsSection(models.Model):
    title = models.CharField(max_length=100)
    desc = models.CharField(max_length=500)

    def __str__(self):
        return self.title

class TeamSection(models.Model):
    title = models.CharField(max_length=100)
    desc = models.CharField(max_length=500)

    def __str__(self):
        return self.title

class ContactSection(models.Model):
    title = models.CharField(max_length=100)
    desc = models.CharField(max_length=500)

    def __str__(self):
        return self.title