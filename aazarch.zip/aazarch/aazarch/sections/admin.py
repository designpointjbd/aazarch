from django.contrib import admin
from .models import *

# Register your models here.


#class PortfolioAdmin(admin.ModelAdmin):
  #  list_display = ("id", "title", "desc", "large_image")

admin.site.register(ContactSection)
admin.site.register(TeamSection)
admin.site.register(ProjectsSection)
admin.site.register(ServicesSection)
